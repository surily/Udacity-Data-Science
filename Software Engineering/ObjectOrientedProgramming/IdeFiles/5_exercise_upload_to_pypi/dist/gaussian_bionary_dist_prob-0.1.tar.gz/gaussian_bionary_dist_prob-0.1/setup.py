from setuptools import setup

setup(name='gaussian_bionary_dist_prob',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['gaussian_bionary_dist_prob'],
      author = 'Stefanie Si',
      author_email = 'surily823@gmail.com',
      zip_safe=False)
